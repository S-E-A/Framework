<?php
/*
Plugin Name: Lollipop Picker
Description: I made this (It is not done)
Version: 1.0
License: GPL
Author: Eric Defore
*/

class Lollipop_Picker{

	/*--------------------------------------------*
     * Attributes
     *--------------------------------------------*/
  
    /** Refers to a single instance of this class. */
    private static $instance = null;
     
    /* Saved color */
    public $color;
	
	/*--------------------------------------------*
     * Constructor
     *--------------------------------------------*/
  
    /**
     * Creates or returns an instance of this class.
     *
     * @return  Lollipop_Picker A single instance of this class.
     */
	 
	 public static function get_instance() {
  
        if ( null == self::$instance ) {
            self::$instance = new self;
        }
  
        return self::$instance;
  
    } // end get_instance;
	
	private function __construct() { 
		
		// Add the page to the admin menu
		add_action( 'admin_menu', array( &$this, 'add_submenu' ) );
		 
		// Register page options
		add_action( 'admin_init', array( &$this, 'register_page_options') );
		 
		// Css rules for Color Picker
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_styles' ) );
		 
		// Register javascript
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_js' ) );
		
		// Throw it into the <head>
		add_action( 'wp_head', array( $this, 'lollipop_picker_head' ) );
		 
		// Get registered color
		$this->color = get_option( 'lollipop-picker' );
	
	}
  
    /*--------------------------------------------*
     * Functions
     *--------------------------------------------*/
      
    /**
     * Function that will add the options page under Appearance Menu.
     */
    public function add_submenu() { 
	
		add_submenu_page( 'themes.php', 'Lollipop Picker Options', 'Lollipop Picker', 'switch_themes', 'lollipop-picker', array( $this, 'display_page') );
	
	}
      
    /**
     * Function that will display the options page.
     */
    public function display_page() { 
	
		if( isset($_POST[ 'lollipop-picker' ]) ) {
			// Read their posted value
			$lollipop_picker_color = $_POST[ 'lollipop-picker' ];
			$this->color = $lollipop_picker_color;

			// Save the posted value in the database
			update_option( 'lollipop-picker', $lollipop_picker_color );
		}
	
		 ?>
		<div class="wrap">
			
			<div class = "alignleft picker">
				<div class = "lollipop-title">
					<img src = "<?php echo plugins_url('/images/lollipop-icon.png', __FILE__); ?>" />
					<h1>Lollipop Picker</h1>
				</div>
				
				<form method = "post" action = "">
				<?php 
					settings_fields(__FILE__);      
					do_settings_sections(__FILE__);
					submit_button();
				?>
				</form>
			</div>
			
			<div class = "alignright preview">
			
				<div class = "lollipop-status">
					<img src = "<?php echo plugins_url('/images/lollipop-status-light.png', __FILE__); ?>" />
				</div>
				<iframe src = "<?php echo get_site_url(); ?>" scrolling = "no"></iframe>
				
				<div class = "lollipop-navigation">
					<img src = "<?php echo plugins_url('/images/lollipop-navigation.png', __FILE__); ?>" />
				</div>
				
			</div>
		
		</div>
			
		</div> <!-- /wrap -->
		<?php  
	
	}
       
    /**
     * Function that will register admin page options.
     */
    public function register_page_options() {
	
		// Add Section for option fields
		add_settings_section( 'lollipop_picker_section', '', array( $this, 'display_section' ), __FILE__ ); // id, title, display cb, page
		 
		// Add Status Bar Color Field
		add_settings_field( 'lollipop_picker_color', 'Status Bar Color', array( $this, 'lollipop_picker_color' ), __FILE__, 'lollipop_picker_section' ); // id, title, display cb, page, section
		 
		// Register Settings
		register_setting( __FILE__, 'lollipop_settings_options', array( $this, 'validate_options' ) ); // option group, option name, sanitize cb 

	}
	
	public function enqueue_admin_styles() {
	
		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_style( 'thickbox' );
		wp_enqueue_style( 'lollipop_picker_css', plugins_url( '/css/lollipop-picker.css', __FILE__ ) );	
	
	}
     
    /**
     * Function that will add javascript file for Color Picker.
     */
    public function enqueue_admin_js() { 
	
		// Make sure to add the wp-color-picker dependency to js file
		wp_enqueue_script( 'lollipop-color-picker', plugins_url( '/js/lollipop-picker.js', __FILE__ ), array( 'jquery', 'wp-color-picker', 'thickbox', 'media-upload' ), '', true  );
	
	}
     
    /**
	 * Function that will validate all fields.
	 */
	public function validate_options( $fields ) { 
		 
		$valid_fields = array();
		 
		// Validate Title Field
		$title = trim( $fields['title'] );
		$valid_fields['title'] = strip_tags( stripslashes( $title ) );
		 
		// Validate Background Color
		$background = trim( $fields['background'] );
		$background = strip_tags( stripslashes( $background ) );
		 
		// Check if is a valid hex color
		if( FALSE === $this->check_color( $background ) ) {
		 
			// Set the error message
			add_settings_error( 'cpa_settings_options', 'cpa_bg_error', 'Insert a valid color for Background', 'error' ); // $setting, $code, $message, $type
			 
			// Get the previous valid value
			$valid_fields['background'] = $this->options['background'];
		 
		} else {
		 
			$valid_fields['background'] = $background;  
		 
		}
		 
		return apply_filters( 'validate_options', $valid_fields, $fields);
	}
	 
	/**
	 * Function that will check if value is a valid HEX color.
	 */
	public function check_color( $value ) { 
		 
		if ( preg_match( '/^#[a-f0-9]{6}$/i', $value ) ) { // if user insert a HEX color with #     
			return true;
		}
		 
		return false;
	}
     
    /**
     * Callback function for settings section
     */
    public function display_section() { /* Leave blank */ } 
     
    /**
     * Functions that display the fields.
     */
     
    public function lollipop_picker_color() {

		$val = $this->color;
		echo '<input type="text" name="lollipop-picker" value="' . $val . '" class="lollipop-color-picker" />';
	
	}
	
	public function lollipop_picker_head() {
		
		if ( '' == ( $color = get_option( 'lollipop-picker' ) ) ){
	
			$lollipop_theme_meta = '';
		
		}
		else{

			$lollipop_theme_meta = '<meta name="theme-color" content="' . $color . '">';
			
		}
	
		echo $lollipop_theme_meta;
		
	}

} // end class
  
Lollipop_Picker::get_instance();

?>