jQuery(function( $ ) {

	function jsPath ( jsfile ) {
 
		var scriptElements = document.getElementsByTagName('script');
		var i, element, myfile;
	 
			for( i = 0; element = scriptElements[i]; i++ ) {
	 
				myfile = element.src;
	 
				if( myfile.indexOf( jsfile ) >= 0 ) {
					var myurl = myfile.substring( 0, myfile.indexOf( jsfile ) );
	 
				}
			}
		return myurl;
	}
	
	function getContrastYIQ(hexcolor){
		var r = parseInt(hexcolor.substr(0,2),16);
		var g = parseInt(hexcolor.substr(2,2),16);
		var b = parseInt(hexcolor.substr(4,2),16);
		var yiq = ((r*299)+(g*587)+(b*114))/1000;
		return (yiq >= 128) ? 'black' : 'white';
	}

   $(document).ready(

		function(){
	   
			var currentColor = $('.lollipop-color-picker');
			
			currentColor = currentColor.val();
			
			var JavaScriptPath = jsPath('lollipop-picker.js');
			
			var pluginPath = JavaScriptPath.substring(0, JavaScriptPath.length - 4);
			
			if ( currentColor == '' ){
				$('.lollipop-status img').attr('src', pluginPath + '/images/lollipop-default.png');
				$('.lollipop-status').css('background-color', 'none');
			}
			else{
			
				var hex = currentColor.substring( 1, currentColor.length );
			
				if( getContrastYIQ(hex) == 'white' ){
				
					$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-status-dark.png');
					
				}
				else{
				
					$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-status-light.png');
					
				}
				
				
				$('.lollipop-status').css('background-color', currentColor);
				
			}
	   
			$('.lollipop-color-picker').wpColorPicker({
					change: function(event, ui) {
						// event = standard jQuery event, produced by whichever control was changed.
						// ui = standard jQuery UI object, with a color member containing a Color.js object
						
						if ( ui.color.toString() == '' ){
							$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-default.png');
							$('.lollipop-status').css( 'background-color', 'none');
						}
						else{
						
							hex = ui.color.toString().substring( 1, ui.color.toString().length );
						
							if( getContrastYIQ(hex) == 'white' ){
				
								$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-status-dark.png');
								
							}
							else{
							
								$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-status-light.png');
								
							}
							
							// change the status bar color
							$('.lollipop-status').css( 'background-color', ui.color.toString());
							
						}

						
					}
					
				}
				
			);
			
			$(document).on('click', '.wp-picker-clear', function(event){
				$('.lollipop-status img').attr( 'src', pluginPath + '/images/lollipop-default.png');
			});
			
			$('.upload-favicon').click(function() {
				tb_show('Large Favicon (192px x 192px Recommended)', 'media-upload.php?referer=lollipop-picker&type=image&TB_iframe=true&post_id=0', false);
				return false;
			});
			
			window.send_to_editor = function(html) {
				var image_url = $('img',html).attr('src');
				$('.favicon-preview').attr('src' ,image_url);
				$('.upload-favicon').val('Change Favicon');
				tb_remove();
			}
	   
	   }
		
   );
   
   $('iframe').load( function() {
		$('iframe').contents().find("head").append(
			$("<style type='text/css'> #wpadminbar{display:none;} body{margin-top: -46px;}	  </style>") // This allows modification of the styling within the iFrame. Just to remove the Admin Bar and be able to see what the site would look like for the average visitor
		);

	});

});